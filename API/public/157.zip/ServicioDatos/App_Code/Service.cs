﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using System.Data.SqlClient;//Biblioteca de clases de conexiòn para Sql-Server

// NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Service1" en el código, en svc y en el archivo de configuración.
public class Service : IService
{
    DataSet ds = new DataSet();//Repositorio universal de datos de ADO.NET
    SqlDataAdapter da;//Clase para ejecutar SP, Vistas, Funciones o Consultas a la BD
    string conexion = "Data Source=localhost; Initial Catalog=Registro; user=sa; password=123";
    string patron = "Pr09r@2";
    public DataSet ValidarUsuario(string login, string password)
	{
        da = new SqlDataAdapter("SP_ValidarUsuario", conexion);
        da.SelectCommand.CommandType = CommandType.StoredProcedure;
        da.SelectCommand.Parameters.Add("@Login", SqlDbType.VarChar).Value = login;
        da.SelectCommand.Parameters.Add("@Password", SqlDbType.VarChar).Value = password;
        da.SelectCommand.Parameters.Add("@Patron", SqlDbType.VarChar).Value = patron;
        da.Fill(ds, "Usuarios");//Ejecutar el SP y los datos se guardan en el DS
        return ds;
	}
}
