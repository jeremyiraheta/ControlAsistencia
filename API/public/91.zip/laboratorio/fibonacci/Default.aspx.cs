﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnOK_Click(object sender, EventArgs e)
    {
        int n = 0;
        double f1 = 0;
        double f2 = 1;
        double f3 = 0;
        try
        {
            n = Convert.ToInt32(txtInput.Text);
        }
        catch (Exception ex)
        {

            txtResult.Text = "Debe ser un entero valido";
        }
        txtResult.Text = "Resultado: ";
        if (n <= 0)
            txtResult.Text = "El numero deber ser mayor que 0";
        if (n > 3)
        {
            txtResult.Text = txtResult.Text + "0 1";
            while (n - 2 > 0)
            {
                f3 = f1 + f2;
                txtResult.Text = txtResult.Text + " " + f3.ToString();
                f1 = f2;
                f2 = f3;
                n--;
            }
        }
        else if (n == 1)
            txtResult.Text = txtResult.Text + " 0";
        else if (n == 2)
            txtResult.Text = txtResult.Text + "0 1";
    }
}