﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Acceso : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    DataSet ds = new DataSet();
    //Instancia de la clase del Servicio Web
    wsDatos.ServiceClient ws = new wsDatos.ServiceClient();
    protected void btnAcceder_Click(object sender, EventArgs e)
    {
        string user = txtLogin.Text;
        string pass = txtPassword.Text;
        ds.Clear();
        ds = ws.ValidarUsuario(user, pass);
        if (ds != null)//Si trae datos
        {
            if (ds.Tables.Count > 0)//Si trae tablas
            {
                if (ds.Tables[0].Rows.Count > 0)//Si trae registros
                { 
                    if (ds.Tables[0].Rows[0]["IdUsuario"].ToString()!="-1")
                    {
                        string nombre = ds.Tables[0].Rows[0]["Nombre"].ToString();
                        lblMensaje.Text = nombre + ". Bienvenido al Sistema!";
                    }
                    else
                        lblMensaje.Text = "Usuario o clave inválidos!";
                }
            }
        }
    }
}